package com.batterysaverplus;

import android.os.Environment;

public class AppConstants {
	
	
   
    public static final String DEVELOPER_ID = "110102625";
    public static final String APP_ID = "211511003";
			
    public static final String Interstitial_Id ="Id";
     public static class Config {
		public static final boolean DEVELOPER_MODE = false;
	}
     
}
